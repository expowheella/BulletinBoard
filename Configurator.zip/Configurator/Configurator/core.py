import pandas as pd
import os

import string

from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.http import request


def core(filename):
    # читаем базу данных кодов
    # df = pd.read_excel(os.path.join(settings.MEDIA_ROOT, 'DATABASE.xlsx'))
    df = pd.read_csv(os.path.join(settings.MEDIA_ROOT, 'NEW_DATABASE.csv'), low_memory=False)
    # читаем переданный нами файл
    req = pd.read_excel(os.path.join(settings.MEDIA_ROOT, filename),
                        dtype={
                            'A': "string",
                            'B': "string",
                            'C': "string",
                            'D1': "string",
                            'D2': "string",
                            'D3': "string",
                            'D4': "string",
                            'DF': "string",
                            'X1': "string",
                            'X2': "string",
                            'X3': "string",
                            'X4': "string",
                            'X5': "string",
                            'H': "string",
                            'Примечание': "string"
                        }, )

    df = df.rename(columns={
        "DKCCODE": "Артикул",
        "Артикул": "Артикул",
        "Description": "Наименование",
    })

#############################################################################################################

    def slicer(data):
        keys = ['material', 'rating', 'poles', 'name', 'id']
        values = [[], [], [], [], []]
        column = dict(zip(keys, values))

        m = column['material']
        r = column['rating']
        p = column['poles']
        c = column['name']
        i = column['id']

        for item in data['Артикул']:
            m.append(item[0:3])
            r.append(item[3:5])
            p.append(item[5])
            c.append(item[6:12])
            i.append(item[12:])

        data['material'] = m
        data['rating'] = r
        data['poles'] = p
        data['name'] = c
        data['id'] = i

        return data

    df = slicer(df)
    df = df.drop_duplicates(subset=['Артикул'])
    BASE = df

    req = slicer(req)

#############################################################################################################

    names = (
        'HEL1AA',
        'HEL2AA',
        'VEL1AA',
        'SEF1AA',
        'TST1AA',
        'FED1AA',
        'MON1AA',
        'JCO1AA',
    )

    for i in req[0:]['name']:
        if i in names:
            # создаем новую таблицу без строки, в которой содержится данное значение
            req = req[req.name != i]
            print(f'{i} - это стандартный элемент, убираем его из таблицы')
        else:
            print(f'{i} - этот элемент оставляем, чтобы найти его в базе или сгенерировать новый код')

#############################################################################################################

    # searching for new values
    df_new_vals = pd.merge(BASE, req,
                           on=['A', 'B', 'C', 'D1', 'D2', 'D3', 'D4', 'DF', 'X1', 'X2', 'X3', 'X4', 'X5', 'H',
                               'material', 'rating', 'poles', 'name'],
                           how='right',
                           indicator='NEW'
                           )
    df_new_vals = df_new_vals[df_new_vals['NEW'] == 'right_only']
    df_new_vals = df_new_vals.assign(Артикул_x=df_new_vals['Артикул_y'])
    df_new_vals = df_new_vals.rename(columns={"Артикул_x": "Артикул"})

    # searching for existing values
    df_existing = pd.merge(BASE, req,
                           on=['A', 'B', 'C', 'D1', 'D2', 'D3', 'D4', 'DF', 'X1', 'X2', 'X3', 'X4', 'X5', 'H',
                               'material', 'rating', 'poles', 'name'],
                           how='left',
                           indicator='EXIST'
                           )
    df_existing = df_existing[df_existing['EXIST'] == 'both']
    df_existing = df_existing.rename(columns={"Артикул_x": "Артикул"})

#############################################################################################################

    df_existing_sub = pd.merge(BASE, req,
                               on=['Артикул', 'A', 'B', 'C', 'D1', 'D2', 'D3', 'D4', 'DF', 'X1', 'X2', 'X3', 'X4', 'X5',
                                   'H', 'material', 'rating', 'poles', 'name'],
                               how='left',
                               indicator='EXIST'
                               )

    df_existing_sub = df_existing_sub[df_existing_sub['EXIST'] == 'both']
    df_existing_sub = df_existing_sub.rename(columns={"Артикул_x": "Артикул"})

#############################################################################################################

    # define values
    values = ['FLXJAA', 'AVIBAA', ]
    # column_name = 'name'
    # drop rows that contain any value in the list
    df_existing = df_existing[df_existing.name.isin(values) == False]

#############################################################################################################
    df_new_vals = df_new_vals.append(df_existing_sub)  # merging with flexible joints (emty parameter elements)

    if len(df_new_vals.iloc[0:]) == 0:
        pass
    else:
        busbar_model = df_new_vals.iloc[0]['material']
        current_rate = df_new_vals.iloc[0]['rating']
        element_type = df_new_vals.iloc[0]['name']

    df_new_vals = df_new_vals.drop_duplicates(
        subset=['Артикул', 'A', 'B', 'C', 'D1', 'D2', 'D3', 'D4', 'DF', 'X1', 'X2', 'X3', 'X4', 'X5', 'H', 'material',
                'rating', 'poles'])

#############################################################################################################

    # GENERATOR
    l = ['PTA', 'PTC', 'PTN', 'DTA', 'DTC', 'DTN', 'LTA', 'LTC', 'LTN']

    for i in df_new_vals.iloc[0:]['Артикул']:
        if i[0:3] not in l:
            print(i)
            df_new_vals = df_new_vals[df_new_vals.Артикул != i]

    def number():

        count = 0

        while count < 10:

            yield count
            count += 1
            if count == 9:
                count = 0

    number = number()

#############################################################################################################

    def letter():

        alphabet = [i for i in string.ascii_uppercase[1:]]  # перебор алфавита

        count = 0

        while count < (len(alphabet) + 1):

            yield alphabet[count]
            count += 1
            if count == (len(alphabet)):
                count = 0

    letter = letter()

#############################################################################################################

    df2 = df
    df2 = df2.rename(columns={
        "DKCCODE": "Артикул",
        "Description": "Наименование",
    })

    codebase = list(df2.iloc[0:]['Артикул'])

#############################################################################################################

    df_new_vals_list = df_new_vals.iloc[0:]['Артикул']
    new_vals = []
    for i in df_new_vals_list:
        new_vals.append(i)

    def new_code(var):
        busbar_model = var[:3]
        current_rate = var[3:5]
        poles = var[5]
        element_type = var[6:12]

        code = busbar_model + current_rate + poles + element_type + str(next(letter)) + str(next(number)) + str(
            next(number)) + 'R'
        #     code = ["PTA25EVEL3AA04C"]
        print(f"сгенерирован новый код: {code}")
        return code


    def code_in(code):
        while code not in codebase:
            print(f'кода нет в базе, можно его туда добавить: {code}')
            return code
        else:
            print('код существует, поэтому сгенерируем новый')
            return new_code(code)

    new_codes = []

    for i in new_vals:
        var = new_code(i)
        new_codes.append(code_in(var))

    codes = new_codes
    df_new_vals = df_new_vals.reset_index()

    df_new_vals = df_new_vals.rename(columns={
        "Наименование": "Description",
    })

    def add_new_vals(dataframe):

        n = 0
        for code in codes:
            dataframe.loc[n, 'Артикул'] = code
            n += 1

        return dataframe

    db = df.append(add_new_vals(df_new_vals))

    df_existing.to_excel(os.path.join(settings.MEDIA_ROOT, 'df_existing_vals.xlsx'))
    df_new_vals.to_excel(os.path.join(settings.MEDIA_ROOT, 'df_new_vals.xlsx'))

    result = pd.concat([df_new_vals, df_existing], join="inner")
    result = result[['Артикул',
                     'A', 'B', 'C', 'D1', 'D2', 'D3', 'D4', 'DF', 'X1', 'X2', 'X3', 'X4', 'X5', 'H', ]]
    result.to_excel(os.path.join(settings.MEDIA_ROOT, f"result.xlsx"))

    # db = db.rename(columns={
    #     "Артикул": "DKCCODE",
    # })
    #
    # db = db.drop([
    #     'NEW',
    #     'material',
    #     'rating',
    #     'poles',
    #     'name',
    #     'id',
    #     'index',
    #     'Unnamed: 0_x',
    #     'Description',
    #     'id_x',
    #     'Unnamed: 0_y',
    #     'Артикул_y',
    #     'Ед. изм.',
    #     'Примечание',
    #     'id_y',
    # ], axis=1)
    #
    # db.to_excel(os.path.join(settings.MEDIA_ROOT, f"DATABASE.xlsx"))
