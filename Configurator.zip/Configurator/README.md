# MyConf
 to cope with my daily routine
