
from django.shortcuts import render
from django.core.files.storage import FileSystemStorage


from Configurator.core import core


def upload(request):
    context = {}
    if request.method == 'POST':
        upload_file = request.FILES['document']
        name = FileSystemStorage().save(upload_file.name, upload_file)
        context['url'] = FileSystemStorage().url(name)

        core(upload_file.name)
        return render(request, 'success.html', context)

    return render(request, 'file_loader.html')
